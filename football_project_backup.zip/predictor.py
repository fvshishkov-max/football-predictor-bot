# predictor.py
import logging
import json
import csv
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Set
from models import Match, LiveStats, GoalSignal, MatchAnalysis
import threading
import math
from collections import defaultdict, deque

logger = logging.getLogger(__name__)

class Predictor:
    """Класс для анализа футбольных матчей в реальном времени с самообучением"""
    
    # Критические таймы для голов (минуты)
    CRITICAL_TIMES = [15, 45, 60, 75, 90]
    
    # Веса для разных типов статистики (будут обучаться)
    DEFAULT_WEIGHTS = {
        'shots': 0.25,
        'shots_ontarget': 0.30,
        'corners': 0.15,
        'dangerous_attacks': 0.20,
        'possession': 0.10
    }
    
    # Пороги для разных таймов (будут корректироваться)
    THRESHOLDS = {
        15: 0.65,  # До 15 минуты нужна очень высокая вероятность
        45: 0.55,  # До перерыва - средняя
        60: 0.50,  # Начало второго тайма - низкая
        75: 0.45,  # Концовка - самая низкая
        90: 0.40   # Добавленное время - экстра низкая
    }
    
    def __init__(self):
        # Интервалы для анализа (в минутах)
        self.analysis_intervals = self.CRITICAL_TIMES
        
        # Параметры модели с самообучением
        self.params = {
            'shots_per_goal': 9.5,
            'ontarget_per_goal': 3.8,
            'corners_per_goal': 5.2,
            'dangerous_attack_per_goal': 2.5,
            'min_minutes_for_analysis': 5,
            'probability_threshold': 0.5,
            'high_probability_threshold': 0.7,
            'learning_rate': 0.05,
            'min_confidence': 0.3,
            'max_confidence': 0.95
        }
        
        # Веса для разных типов статистики (обучаемые)
        self.weights = self.DEFAULT_WEIGHTS.copy()
        
        # Пороги для разных таймов (обучаемые)
        self.thresholds = self.THRESHOLDS.copy()
        
        # Статистика точности
        self.accuracy_stats = {
            'total_signals': 0,
            'correct_signals': 0,
            'accuracy_rate': 0,
            'avg_time_error': 0,
            'goals_predicted': 0,
            'goals_actual': 0,
            'signals_by_time': {t: {'total': 0, 'correct': 0} for t in self.CRITICAL_TIMES},
            'league_stats': defaultdict(lambda: {'total': 0, 'correct': 0, 'avg_shots': 0}),
            'team_stats': defaultdict(lambda: {'signals': 0, 'goals': 0, 'avg_time': 0})
        }
        
        # Кэш для ускорения
        self.cache = {
            'match_analysis': {},  # match_id -> (timestamp, analysis)
            'team_signals': defaultdict(set),  # team_id -> set of signal_times
            'league_stats': {},
            'cache_ttl': 60  # секунд
        }
        
        # История сигналов
        self.signals_history = []
        self.history_lock = threading.RLock()  # Reentrant lock
        
        # Очередь для сохранения
        self.save_queue = deque(maxlen=100)
        self.last_save_time = 0
        self.save_interval = 10  # секунд
        
        # Загружаем данные
        self.load_accuracy_stats()
        self.load_signals_history()
        self.load_weights()
        self.load_thresholds()
        
        # Запускаем фоновое сохранение
        self.start_auto_save()
        
        logger.info(f"📊 Модель инициализирована с порогами: {self.thresholds}")
    
    def analyze_live_match(self, match: Match, stats: LiveStats) -> MatchAnalysis:
        """Анализирует live матч с использованием кэша"""
        # Проверяем кэш
        cache_key = match.id
        cached = self.cache['match_analysis'].get(cache_key)
        if cached:
            timestamp, analysis = cached
            if time.time() - timestamp < self.cache['cache_ttl']:
                return analysis
        
        if not stats:
            stats = LiveStats(minute=match.minute or 0)
        
        current_minute = match.minute or 0
        current_goals = (match.home_score or 0) + (match.away_score or 0)
        
        # Получаем статистику лиги для корректировки
        league_factor = self._get_league_factor(match.league_id, match.league_name)
        
        # Получаем историю команд
        team_factor = self._get_team_factor(match.home_team.id, match.away_team.id)
        
        # Рассчитываем активность
        activity_level, activity_description = self._calculate_activity(stats, current_minute)
        
        # Находим следующий сигнал с учетом всех факторов
        next_signal = self._find_next_goal_signal(
            stats, current_minute, current_goals, 
            league_factor, team_factor, match
        )
        
        # Рассчитываем атакующий потенциал
        attack_potential = self._calculate_attack_potential(stats, current_minute)
        
        analysis = MatchAnalysis(
            match_id=match.id,
            timestamp=datetime.now(),
            minute=current_minute,
            score=f"{match.home_score}:{match.away_score}",
            stats=stats,
            activity_level=activity_level,
            activity_description=activity_description,
            attack_potential=attack_potential,
            next_signal=next_signal,
            has_signal=next_signal is not None
        )
        
        # Сохраняем в кэш
        self.cache['match_analysis'][cache_key] = (time.time(), analysis)
        
        if next_signal:
            logger.info(f"⚽ Сигнал в матче {match.id}: {match.home_team.name}-{match.away_team.name} "
                       f"~{next_signal.predicted_minute}' ({next_signal.probability:.1f}%)")
        
        return analysis
    
    def _get_league_factor(self, league_id: int, league_name: str) -> float:
        """Получает фактор лиги на основе статистики"""
        if not league_id:
            return 1.0
        
        stats = self.accuracy_stats['league_stats'].get(str(league_id))
        if not stats or stats['total'] < 5:
            return 1.0
        
        accuracy = stats['correct'] / stats['total'] if stats['total'] > 0 else 0.5
        avg_shots = stats['avg_shots']
        
        # Корректируем фактор
        factor = 1.0
        if accuracy > 0.7:
            factor *= 1.1  # Лига с хорошей предсказуемостью
        elif accuracy < 0.3:
            factor *= 0.9  # Непредсказуемая лига
        
        if avg_shots > 10:
            factor *= 1.05  # Результативная лига
        
        return factor
    
    def _get_team_factor(self, home_id: int, away_id: int) -> float:
        """Получает фактор команд на основе истории"""
        home_stats = self.accuracy_stats['team_stats'].get(str(home_id), {})
        away_stats = self.accuracy_stats['team_stats'].get(str(away_id), {})
        
        factor = 1.0
        
        # Учитываем историю команд
        for stats in [home_stats, away_stats]:
            if stats and stats.get('signals', 0) > 0:
                avg_time = stats.get('avg_time', 90)
                if avg_time < 60:
                    factor *= 1.1  # Команда забивает рано
                elif avg_time > 75:
                    factor *= 0.95  # Команда забивает поздно
        
        return factor
    
    def _calculate_activity(self, stats: LiveStats, current_minute: int) -> tuple:
        """Рассчитывает текущую активность команд с учетом статистики"""
        if current_minute < self.params['min_minutes_for_analysis']:
            return 'Низкая', 'Матч только начался, нужно больше данных'
        
        shots_per_minute = stats.total_shots / current_minute if current_minute > 0 else 0
        ontarget_ratio = stats.total_shots_ontarget / stats.total_shots if stats.total_shots > 0 else 0
        
        if shots_per_minute > 0.3:
            return 'Экстра высокая', f'Шквал атак! {stats.total_shots} ударов за {current_minute} мин'
        elif shots_per_minute > 0.2:
            return 'Очень высокая', f'Активный футбол, {stats.total_shots} ударов'
        elif shots_per_minute > 0.15:
            return 'Высокая', 'Команды много атакуют'
        elif shots_per_minute > 0.1:
            return 'Средняя', 'Умеренная активность'
        elif shots_per_minute > 0.05:
            return 'Низкая', 'Мало опасных моментов'
        else:
            return 'Очень низкая', 'Скучный матч'
    
    def _find_next_goal_signal(self, stats: LiveStats, current_minute: int, 
                               current_goals: int, league_factor: float = 1.0,
                               team_factor: float = 1.0, match: Match = None) -> Optional[GoalSignal]:
        """Находит ближайший сигнал на гол с жестким отбором по таймам"""
        if current_minute < self.params['min_minutes_for_analysis']:
            return None
        
        signals = []
        
        for interval in self.analysis_intervals:
            if interval <= current_minute:
                continue
            
            minutes_left = interval - current_minute
            
            # Рассчитываем базовую вероятность
            base_probability = self._calculate_goal_probability(
                stats, current_minute, minutes_left, current_goals
            )
            
            # Применяем факторы
            adjusted_probability = base_probability * league_factor * team_factor
            
            # Получаем порог для этого тайма
            threshold = self.thresholds.get(interval, 0.5)
            
            # Жесткий отбор по таймам
            if adjusted_probability >= threshold:
                # Дополнительные проверки для каждого тайма
                if not self._validate_time_signal(stats, current_minute, interval, adjusted_probability):
                    continue
                
                # Проверяем, не было ли уже сигнала для этих команд в этом тайме
                if match and self._is_duplicate_signal(match, interval):
                    continue
                
                signal_type = 'HIGH' if adjusted_probability >= self.params['high_probability_threshold'] else 'NORMAL'
                
                # Генерируем описание
                description = self._generate_signal_description(
                    adjusted_probability, minutes_left, interval, stats
                )
                
                signal = GoalSignal(
                    match_id=0,
                    predicted_minute=interval,
                    probability=adjusted_probability * 100,
                    signal_type=signal_type,
                    description=description,
                    timestamp=datetime.now(),
                    stats=stats.to_dict(),
                    minutes_left=minutes_left
                )
                signals.append(signal)
        
        if signals:
            # Выбираем сигнал с наивысшей вероятностью, но не позднее 90 минуты
            valid_signals = [s for s in signals if s.predicted_minute <= 90]
            if valid_signals:
                return max(valid_signals, key=lambda x: x.probability)
        return None
    
    def _validate_time_signal(self, stats: LiveStats, current_minute: int, 
                              target_minute: int, probability: float) -> bool:
        """Дополнительная валидация сигнала по тайму"""
        
        # Для первого тайма (до 45 минуты)
        if target_minute <= 45:
            if current_minute < 30 and stats.total_shots < 5:
                return False  # Мало ударов в начале
        
        # Для начала второго тайма (45-60)
        elif target_minute <= 60:
            if current_minute > 45 and stats.total_shots < 8:
                return False  # Мало ударов после перерыва
        
        # Для концовки (75-90)
        elif target_minute >= 75:
            if stats.total_shots < 10:
                return False  # Слишком мало ударов для голов в концовке
        
        return True
    
    def _is_duplicate_signal(self, match: Match, target_minute: int) -> bool:
        """Проверяет, не было ли уже сигнала для этих команд в этом тайме"""
        team_key = f"{match.home_team.id}_{match.away_team.id}"
        
        # Определяем тайм
        if target_minute <= 45:
            time_range = "first_half"
        elif target_minute <= 60:
            time_range = "early_second"
        elif target_minute <= 75:
            time_range = "mid_second"
        else:
            time_range = "late_second"
        
        signal_id = f"{team_key}_{time_range}"
        
        if signal_id in self.cache['team_signals'][team_key]:
            logger.debug(f"Дубликат сигнала для команд {team_key} в тайме {time_range}")
            return True
        
        self.cache['team_signals'][team_key].add(time_range)
        return False
    
    def _generate_signal_description(self, probability: float, minutes_left: int, 
                                     target_minute: int, stats: LiveStats) -> str:
        """Генерирует описание сигнала на основе статистики"""
        if probability >= 0.8:
            if minutes_left <= 15:
                return f"🚨 КРИТИЧЕСКИ ВЫСОКАЯ вероятность гола до {target_minute}'!"
            else:
                return f"🔥 Экстра высокая вероятность гола к {target_minute}'"
        elif probability >= 0.7:
            return f"⚡ Очень высокая вероятность гола к {target_minute}'"
        elif probability >= 0.6:
            return f"📊 Хорошая вероятность гола к {target_minute}'"
        else:
            return f"📈 Повышенная вероятность гола к {target_minute}'"
    
    def _calculate_goal_probability(self, stats: LiveStats, current_minute: int,
                                    minutes_left: int, current_goals: int) -> float:
        """Рассчитывает вероятность гола с использованием обучаемых весов"""
        if minutes_left <= 0:
            return 0
        
        factors = []
        
        # Удары (с весом)
        if current_minute > 0:
            shots_per_minute = stats.total_shots / current_minute
            expected_shots = shots_per_minute * minutes_left
            shots_factor = min(1.0, expected_shots / self.params['shots_per_goal'])
            factors.append(shots_factor * self.weights['shots'])
        
        # Удары в створ (самый важный фактор)
        if current_minute > 0 and stats.total_shots_ontarget > 0:
            ontarget_per_minute = stats.total_shots_ontarget / current_minute
            expected_ontarget = ontarget_per_minute * minutes_left
            ontarget_factor = min(1.0, expected_ontarget / self.params['ontarget_per_goal'])
            factors.append(ontarget_factor * self.weights['shots_ontarget'])
        
        # Угловые
        if current_minute > 0 and stats.total_corners > 0:
            corners_per_minute = stats.total_corners / current_minute
            expected_corners = corners_per_minute * minutes_left
            corners_factor = min(1.0, expected_corners / self.params['corners_per_goal'])
            factors.append(corners_factor * self.weights['corners'])
        
        # Опасные атаки
        if current_minute > 0 and stats.total_dangerous_attacks > 0:
            dangerous_per_minute = stats.total_dangerous_attacks / current_minute
            expected_dangerous = dangerous_per_minute * minutes_left
            dangerous_factor = min(1.0, expected_dangerous / self.params['dangerous_attack_per_goal'])
            factors.append(dangerous_factor * self.weights['dangerous_attacks'])
        
        # Владение мячом
        possession_diff = abs(stats.possession_home - stats.possession_away)
        possession_factor = min(1.0, possession_diff / 30)  # Разница во владении
        factors.append(possession_factor * self.weights['possession'])
        
        probability = sum(factors)
        
        # Корректировка на уже забитые голы
        if current_goals > 0:
            probability *= (1 + current_goals * 0.1)  # +10% за каждый гол
        
        # Время матча влияет на вероятность
        time_factor = minutes_left / 45
        probability *= min(1.0, time_factor * 1.3)
        
        return min(self.params['max_confidence'], probability)
    
    def _calculate_attack_potential(self, stats: LiveStats, current_minute: int) -> str:
        """Определяет атакующий потенциал команд"""
        if current_minute < 5:
            return "⚖️ Разведка"
        
        shots_per_minute = stats.total_shots / current_minute if current_minute > 0 else 0
        ontarget_ratio = stats.total_shots_ontarget / stats.total_shots if stats.total_shots > 0 else 0
        
        if shots_per_minute > 0.25 and ontarget_ratio > 0.4:
            return "🔥🔥🔥🔥 Разгромный"
        elif shots_per_minute > 0.2:
            return "🔥🔥🔥 Очень высокий"
        elif shots_per_minute > 0.15:
            return "🔥🔥 Высокий"
        elif shots_per_minute > 0.1:
            return "🔥 Средний"
        elif shots_per_minute > 0.05:
            return "💧 Низкий"
        else:
            return "💧💧 Очень низкий"
    
    def confirm_goal(self, match_id: int, signal_minute: int, actual_minute: int, 
                     signal_probability: float = None) -> Dict:
        """
        Подтверждает гол и обновляет статистику для самообучения
        """
        with self.history_lock:
            result = {
                'was_correct': False,
                'time_error': abs(signal_minute - actual_minute),
                'signal_found': False,
                'match_id': match_id,
                'actual_minute': actual_minute,
                'signal_minute': signal_minute
            }
            
            # Ищем сигнал в истории
            signal_found = False
            for signal in self.signals_history:
                if (signal.get('match_id') == match_id and 
                    signal.get('signal_minute') == signal_minute):
                    
                    signal['actual_goal_minute'] = actual_minute
                    signal['time_error'] = result['time_error']
                    signal['was_correct'] = result['time_error'] <= 10
                    signal['confirmed_at'] = datetime.now().isoformat()
                    signal_found = True
                    result['signal_found'] = True
                    result['was_correct'] = signal['was_correct']
                    break
            
            if signal_found:
                # Обновляем статистику по таймам
                time_key = self._get_time_key(signal_minute)
                self.accuracy_stats['signals_by_time'][time_key]['total'] += 1
                if result['was_correct']:
                    self.accuracy_stats['signals_by_time'][time_key]['correct'] += 1
                
                # Обучаем модель на основе результата
                self._learn_from_result(signal_minute, result['time_error'], 
                                       signal_probability, result['was_correct'])
            
            self.accuracy_stats['goals_actual'] += 1
            
            # Планируем сохранение
            self.schedule_save()
        
        return result
    
    def _get_time_key(self, minute: int) -> int:
        """Определяет ключ тайма для минуты"""
        for t in self.CRITICAL_TIMES:
            if minute <= t:
                return t
        return 90
    
    def _learn_from_result(self, predicted_minute: int, time_error: int, 
                          probability: float, was_correct: bool):
        """Самообучение на основе результатов"""
        
        # Корректируем пороги для разных таймов
        if was_correct:
            # Если прогноз был точен, можно немного снизить порог
            self.thresholds[predicted_minute] *= 0.98
        else:
            # Если ошибка, повышаем порог
            self.thresholds[predicted_minute] *= 1.02
        
        # Ограничиваем пороги
        for t in self.thresholds:
            self.thresholds[t] = max(0.3, min(0.8, self.thresholds[t]))
        
        # Корректируем веса на основе точности
        if probability:
            error_ratio = time_error / 45  # Нормализованная ошибка
            
            if was_correct:
                # Увеличиваем веса для точных прогнозов
                for key in self.weights:
                    self.weights[key] *= (1 + self.params['learning_rate'] * (1 - error_ratio))
            else:
                # Уменьшаем веса для неточных
                for key in self.weights:
                    self.weights[key] *= (1 - self.params['learning_rate'] * error_ratio)
            
            # Нормализуем веса, чтобы сумма была 1
            total = sum(self.weights.values())
            if total > 0:
                for key in self.weights:
                    self.weights[key] /= total
        
        logger.debug(f"🤖 Обновлены пороги: {self.thresholds}, веса: {self.weights}")
    
    def save_signal_to_history(self, match: Match, signal: GoalSignal):
        """Сохраняет сигнал в историю"""
        with self.history_lock:
            # Проверяем дубликаты
            for s in self.signals_history:
                if (s.get('match_id') == match.id and 
                    s.get('signal_minute') == signal.predicted_minute):
                    return
            
            entry = {
                'timestamp': datetime.now().isoformat(),
                'match_id': match.id,
                'home_team': match.home_team.name,
                'home_id': match.home_team.id,
                'away_team': match.away_team.name,
                'away_id': match.away_team.id,
                'league_id': match.league_id,
                'league_name': match.league_name,
                'signal_minute': signal.predicted_minute,
                'signal_probability': signal.probability,
                'match_minute': match.minute,
                'score': match.score,
                'shots_total': signal.stats.get('shots', {}).get('total', 0) if signal.stats else 0,
                'shots_ontarget': signal.stats.get('shots', {}).get('ontarget_total', 0) if signal.stats else 0
            }
            
            self.signals_history.append(entry)
            logger.info(f"💾 Сигнал {len(self.signals_history)}: {match.home_team.name}-{match.away_team.name} "
                       f"~{signal.predicted_minute}' ({signal.probability:.1f}%)")
            
            # Обновляем статистику
            self.accuracy_stats['total_signals'] = len(self.signals_history)
            self.accuracy_stats['goals_predicted'] = len(self.signals_history)
            
            # Планируем сохранение
            self.schedule_save()
    
    def schedule_save(self):
        """Планирует сохранение данных"""
        self.save_queue.append(time.time())
        if time.time() - self.last_save_time > self.save_interval:
            self._save_all()
    
    def start_auto_save(self):
        """Запускает автосохранение"""
        def auto_saver():
            while True:
                time.sleep(30)  # Сохраняем каждые 30 секунд
                self._save_all()
        
        thread = threading.Thread(target=auto_saver, daemon=True)
        thread.start()
    
    def _save_all(self):
        """Сохраняет все данные"""
        try:
            with self.history_lock:
                self._save_stats()
                self._save_signals()
                self._save_weights()
                self._save_thresholds()
                self.last_save_time = time.time()
        except Exception as e:
            logger.error(f"Ошибка сохранения: {e}")
    
    def _save_stats(self):
        """Сохраняет статистику"""
        try:
            with open('signal_accuracy.json', 'w', encoding='utf-8') as f:
                json.dump({
                    'stats': self.accuracy_stats,
                    'params': self.params,
                    'last_updated': datetime.now().isoformat()
                }, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения статистики: {e}")
    
    def _save_weights(self):
        """Сохраняет веса модели"""
        try:
            with open('model_weights.json', 'w', encoding='utf-8') as f:
                json.dump({
                    'weights': self.weights,
                    'last_updated': datetime.now().isoformat()
                }, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения весов: {e}")
    
    def _save_thresholds(self):
        """Сохраняет пороги"""
        try:
            with open('model_thresholds.json', 'w', encoding='utf-8') as f:
                json.dump({
                    'thresholds': self.thresholds,
                    'last_updated': datetime.now().isoformat()
                }, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения порогов: {e}")
    
    def _save_signals(self):
        """Сохраняет историю сигналов"""
        try:
            # Сохраняем последние 200 сигналов
            recent = self.signals_history[-200:]
            
            # Сохраняем в JSON
            with open('signals_history_latest.json', 'w', encoding='utf-8') as f:
                json.dump(recent, f, ensure_ascii=False, indent=2)
            
            # Сохраняем в CSV для анализа
            if recent:
                csv_filename = f'signals_history_{datetime.now().strftime("%Y%m%d")}.csv'
                with open(csv_filename, 'w', encoding='utf-8', newline='') as f:
                    fieldnames = ['timestamp', 'match_id', 'home_team', 'away_team', 
                                 'signal_minute', 'signal_probability', 'match_minute', 'score']
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    for s in recent:
                        writer.writerow({k: s.get(k) for k in fieldnames})
            
            logger.debug(f"💾 История сигналов сохранена ({len(recent)} записей)")
            
        except Exception as e:
            logger.error(f"Ошибка сохранения истории: {e}")
    
    def load_accuracy_stats(self):
        """Загружает статистику точности"""
        try:
            if os.path.exists('signal_accuracy.json'):
                with open('signal_accuracy.json', 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.accuracy_stats.update(data.get('stats', {}))
                    self.params.update(data.get('params', {}))
                logger.info(f"📊 Загружена статистика: точность {self.accuracy_stats['accuracy_rate']:.1f}%")
        except Exception as e:
            logger.error(f"Ошибка загрузки статистики: {e}")
    
    def load_weights(self):
        """Загружает веса модели"""
        try:
            if os.path.exists('model_weights.json'):
                with open('model_weights.json', 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.weights.update(data.get('weights', {}))
                logger.info(f"⚖️ Загружены веса модели: {self.weights}")
        except Exception as e:
            logger.error(f"Ошибка загрузки весов: {e}")
    
    def load_thresholds(self):
        """Загружает пороги"""
        try:
            if os.path.exists('model_thresholds.json'):
                with open('model_thresholds.json', 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.thresholds.update(data.get('thresholds', {}))
                logger.info(f"🎯 Загружены пороги: {self.thresholds}")
        except Exception as e:
            logger.error(f"Ошибка загрузки порогов: {e}")
    
    def load_signals_history(self):
        """Загружает историю сигналов"""
        try:
            if os.path.exists('signals_history_latest.json'):
                with open('signals_history_latest.json', 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    if isinstance(loaded, list):
                        self.signals_history = loaded
                        self.accuracy_stats['total_signals'] = len(loaded)
                        self.accuracy_stats['goals_predicted'] = len(loaded)
                logger.info(f"📥 Загружено {len(self.signals_history)} сигналов")
                
        except Exception as e:
            logger.error(f"Ошибка загрузки истории: {e}")
    
    def clear_cache(self):
        """Очищает кэш"""
        self.cache['match_analysis'].clear()
        logger.debug("🧹 Кэш очищен")