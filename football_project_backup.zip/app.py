# app.py
import tkinter as tk
import asyncio
import threading
import time
import logging
from datetime import datetime
from typing import Dict, List, Optional, Set
import json
import os

from api_client import SStatsClient
from predictor import Predictor
from telegram_bot import TelegramBot
from database import Database
from ui import FootballAppUI
from models import Match, LiveStats, MatchAnalysis, Prediction
from bot_state import BotState
import config

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('football_bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class FootballApp:
    """Главный класс приложения"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.ui = FootballAppUI(self.root)
        
        # Инициализация компонентов
        self.api_client = SStatsClient(
            api_key=config.SSTATS_API_KEY, 
            timezone=config.TIMEZONE,
            use_mock=config.USE_MOCK_DATA
        )
        self.predictor = Predictor()
        self.telegram = TelegramBot(config.BOT_TOKEN, config.CHANNEL_ID)
        self.db = Database()
        self.state = BotState()
        
        # Данные с кэшированием
        self.matches: List[Match] = []
        self.all_matches: List[Match] = []
        self.analyses: Dict[int, MatchAnalysis] = {}
        self.selected_matches: Set[int] = set()
        self.sent_signals: Set[str] = set()
        
        # Тайминг
        self.last_signal_time = 0
        self.signal_cooldown = 5
        self.update_in_progress = False
        self.stop_monitoring = False
        self.last_update_time = 0
        self.update_interval = 20  # секунд
        
        # Подключаем обработчики UI
        self.ui.on_refresh_callback = self.refresh_matches
        self.ui.on_analyze_callback = self.analyze_match
        self.ui.on_track_callback = self.toggle_tracking
        self.ui.on_send_callback = self.send_signal_to_telegram
        self.ui.on_show_all_callback = self.show_all_matches
        self.ui.on_auto_send_toggle = self.toggle_auto_send
        
        # Загружаем данные
        self.load_from_state()
        
        # Запускаем мониторинг
        self.start_monitoring()
        
        # Первое обновление
        self.root.after(100, self.refresh_matches)
        
        logger.info("✅ Приложение запущено")
        logger.info(f"📊 Статистика: сигналов {self.predictor.accuracy_stats['total_signals']}, "
                   f"пороги: {self.predictor.thresholds}")
    
    def load_from_state(self):
        """Загружает данные из сохраненного состояния"""
        self.sent_signals = set(self.state.state['sent_signals'])
        
        try:
            if os.path.exists('selected_matches.json'):
                with open('selected_matches.json', 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.selected_matches = set(data.get('selected', []))
        except Exception as e:
            logger.error(f"Ошибка загрузки выбранных матчей: {e}")
    
    def analyze_match(self, match):
        """Анализ выбранного матча"""
        self.ui.selected_match = match
        
        analysis = self.analyses.get(match.id)
        if analysis and isinstance(analysis, MatchAnalysis):
            text = analysis.format_telegram_message(match)
            self.ui.update_analysis(text)
        else:
            home_flag = self._get_flag_emoji(match.home_team.country_code)
            away_flag = self._get_flag_emoji(match.away_team.country_code)
            
            text = f"📊 ИНФОРМАЦИЯ О МАТЧЕ\n\n"
            text += f"{home_flag} {match.home_team.name} vs {away_flag} {match.away_team.name}\n"
            text += f"⚽ Счет: {match.score}\n"
            if match.minute:
                text += f"⏱️ Минута: {match.minute}'\n"
            text += f"🏆 Лига: {match.league_name}\n"
            text += f"\n🔄 Анализ еще не выполнен"
            self.ui.update_analysis(text)
    
    def refresh_matches(self):
        """Обновление списка матчей с кэшированием"""
        # Проверяем, не слишком часто обновляемся
        current_time = time.time()
        if current_time - self.last_update_time < self.update_interval:
            logger.debug("Слишком частые обновления, пропускаем")
            return
        
        if self.update_in_progress:
            logger.debug("Обновление уже выполняется, пропускаем")
            return
        
        self.update_in_progress = True
        self.last_update_time = current_time
        self.ui.set_status("🟡 ЗАГРУЗКА...", "orange")
        
        def load():
            try:
                # Используем новый event loop
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                # Параллельные запросы для ускорения
                tasks = [
                    self.api_client.get_live_matches(),
                    self.api_client.get_today_matches()
                ]
                
                results = loop.run_until_complete(asyncio.gather(*tasks, return_exceptions=True))
                
                matches = results[0] if not isinstance(results[0], Exception) else []
                all_matches = results[1] if not isinstance(results[1], Exception) else []
                
                if isinstance(results[0], Exception):
                    logger.error(f"Ошибка получения LIVE матчей: {results[0]}")
                if isinstance(results[1], Exception):
                    logger.error(f"Ошибка получения всех матчей: {results[1]}")
                
                # Анализируем только LIVE матчи
                analyses = {}
                for match in matches:
                    try:
                        stats = loop.run_until_complete(
                            self.api_client.get_match_statistics(match.id)
                        )
                        
                        if stats:
                            analysis = self.predictor.analyze_live_match(match, stats)
                            analyses[match.id] = analysis
                            
                            # Проверяем сигналы
                            self._check_goal_signals(match, analysis)
                            
                    except Exception as e:
                        logger.error(f"Ошибка обработки матча {match.id}: {e}")
                
                loop.close()
                
                # Обновляем данные
                self.matches = matches
                self.all_matches = all_matches
                self.analyses = analyses
                
                # Обновляем UI в главном потоке
                self.root.after(0, self.update_ui)
                self.root.after(0, lambda: self.ui.set_status("🟢 ONLINE", "green"))
                
                if not matches:
                    self.root.after(0, lambda: self.ui.update_analysis(
                        "🔴 Сейчас нет LIVE матчей.\n\n"
                        "Используйте кнопку 'Все матчи' для просмотра расписания."
                    ))
                
            except Exception as e:
                logger.error(f"❌ Ошибка загрузки: {e}")
                self.root.after(0, lambda: self.ui.set_status("🔴 ОШИБКА", "red"))
            
            finally:
                self.update_in_progress = False
        
        # Запускаем в отдельном потоке
        thread = threading.Thread(target=load, daemon=True)
        thread.start()
    
    def _check_goal_signals(self, match: Match, analysis: MatchAnalysis):
        """Проверяет и отправляет сигналы на гол"""
        if not analysis.has_signal or not analysis.next_signal:
            return
        
        signal = analysis.next_signal
        signal_key = f"{match.id}_{signal.predicted_minute}"
        
        # Проверяем, не отправляли ли уже
        if self.state.is_signal_sent(signal_key):
            return
        
        # Проверяем cooldown
        current_time = time.time()
        if current_time - self.last_signal_time < self.signal_cooldown:
            return
        
        # Автоотправка
        if self.ui.auto_send_var.get():
            message = analysis.format_telegram_message(match)
            if self.telegram.send_goal_signal(match, analysis, message):
                self.state.add_sent_signal(signal_key)
                self.last_signal_time = current_time
                
                # Сохраняем в историю
                self.predictor.save_signal_to_history(match, signal)
                
                logger.info(f"📤 Сигнал {match.id}: {match.home_team.name}-{match.away_team.name} "
                           f"~{signal.predicted_minute}' ({signal.probability:.1f}%)")
    
    def show_all_matches(self):
        """Показывает все матчи на сегодня"""
        if not self.all_matches:
            self.ui.update_analysis("📅 Загружаю расписание...")
            self.refresh_matches()
            return
        
        live = [m for m in self.all_matches if m.is_live]
        scheduled = [m for m in self.all_matches if not m.is_live and not m.is_finished]
        finished = [m for m in self.all_matches if m.is_finished]
        
        text = f"📋 ВСЕ МАТЧИ НА СЕГОДНЯ ({len(self.all_matches)})\n\n"
        
        if live:
            text += f"🔴 LIVE ({len(live)}):\n"
            for m in live[:5]:
                home_flag = self._get_flag_emoji(m.home_team.country_code)
                away_flag = self._get_flag_emoji(m.away_team.country_code)
                text += f"   • {home_flag} {m.home_team.name} vs {away_flag} {m.away_team.name}"
                if m.minute:
                    text += f" ({m.minute}')"
                text += f" [{m.home_score}:{m.away_score}]\n"
            text += "\n"
        
        if scheduled:
            text += f"⏳ ПРЕДСТОЯЩИЕ ({len(scheduled)}):\n"
            for m in scheduled[:5]:
                home_flag = self._get_flag_emoji(m.home_team.country_code)
                away_flag = self._get_flag_emoji(m.away_team.country_code)
                text += f"   • {home_flag} {m.home_team.name} vs {away_flag} {m.away_team.name}\n"
            text += "\n"
        
        if finished:
            text += f"✅ ЗАВЕРШЕННЫЕ ({len(finished)}):\n"
            for m in finished[:5]:
                home_flag = self._get_flag_emoji(m.home_team.country_code)
                away_flag = self._get_flag_emoji(m.away_team.country_code)
                text += f"   • {home_flag} {m.home_team.name} {m.home_score}-{m.away_score} {away_flag} {m.away_team.name}\n"
        
        self.ui.update_analysis(text)
    
    def _get_flag_emoji(self, country_code: str) -> str:
        """Возвращает эмодзи флага по коду страны"""
        if not country_code:
            return "🌍"
        
        flags = {
            'england': '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'eng': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
            'spain': '🇪🇸', 'esp': '🇪🇸',
            'italy': '🇮🇹', 'ita': '🇮🇹',
            'germany': '🇩🇪', 'ger': '🇩🇪',
            'france': '🇫🇷', 'fra': '🇫🇷',
            'netherlands': '🇳🇱', 'ned': '🇳🇱',
            'portugal': '🇵🇹', 'por': '🇵🇹',
            'turkey': '🇹🇷', 'tur': '🇹🇷',
            'russia': '🇷🇺', 'rus': '🇷🇺',
            'ukraine': '🇺🇦', 'ukr': '🇺🇦',
            'belgium': '🇧🇪', 'bel': '🇧🇪',
            'switzerland': '🇨🇭', 'sui': '🇨🇭',
            'austria': '🇦🇹', 'aut': '🇦🇹',
            'scotland': '🏴󠁧󠁢󠁳󠁣󠁴󠁿', 'sco': '🏴󠁧󠁢󠁳󠁣󠁴󠁿',
            'wales': '🏴󠁧󠁢󠁷󠁬󠁳󠁿', 'wal': '🏴󠁧󠁢󠁷󠁬󠁳󠁿',
            'usa': '🇺🇸', 'brazil': '🇧🇷', 'bra': '🇧🇷',
            'argentina': '🇦🇷', 'arg': '🇦🇷', 'japan': '🇯🇵', 'jpn': '🇯🇵',
        }
        
        return flags.get(country_code.lower(), '🌍')
    
    def update_ui(self):
        """Обновляет интерфейс"""
        predictions = {}
        for match_id, analysis in self.analyses.items():
            if isinstance(analysis, MatchAnalysis):
                pred = Prediction(
                    match_id=match_id,
                    type='live',
                    timestamp=datetime.now(),
                    next_goal_minute=analysis.next_signal.predicted_minute if analysis.next_signal else None,
                    next_goal_probability=analysis.next_signal.probability if analysis.next_signal else 0,
                    attack_potential=analysis.attack_potential,
                    match_minute=analysis.minute,
                    current_score=analysis.score,
                    shots_stats=analysis.stats.to_dict().get('shots', {}),
                    possession_stats=analysis.stats.to_dict().get('possession', {})
                )
                predictions[match_id] = pred
        
        self.ui.update_matches(self.matches, predictions, self.selected_matches, {})
        self.ui.update_alerts(self.db.get_recent_alerts(10))
        
        stats = {
            'total_predictions': self.predictor.accuracy_stats['total_signals'],
            'accuracy_rate': self.predictor.accuracy_stats['accuracy_rate'],
            'goals_predictions': self.predictor.accuracy_stats['total_signals'],
            'goals_accuracy': self.predictor.accuracy_stats['accuracy_rate'],
            'shots_per_goal': self.predictor.params['shots_per_goal'],
            'ontarget_per_goal': self.predictor.params['ontarget_per_goal'],
            'threshold': self.predictor.params['probability_threshold'] * 100,
            'thresholds': self.predictor.thresholds,
            'weights': self.predictor.weights
        }
        self.ui.update_stats(stats)
        self.ui.update_footer()
    
    def toggle_tracking(self, match):
        """Включает/выключает отслеживание матча"""
        match_id = match.id
        if match_id in self.selected_matches:
            self.selected_matches.remove(match_id)
            logger.info(f"⏸️ Отслеживание матча {match_id} остановлено")
        else:
            self.selected_matches.add(match_id)
            logger.info(f"🔔 Начато отслеживание матча {match_id}")
        
        self.save_selected_matches()
        self.update_ui()
    
    def save_selected_matches(self):
        """Сохраняет выбранные для отслеживания матчи"""
        try:
            with open('selected_matches.json', 'w', encoding='utf-8') as f:
                json.dump({'selected': list(self.selected_matches)}, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения выбранных матчей: {e}")
    
    def toggle_auto_send(self, enabled: bool):
        """Включает/выключает автоотправку"""
        logger.info(f"🤖 Автоотправка сигналов {'включена' if enabled else 'выключена'}")
    
    def send_signal_to_telegram(self):
        """Ручная отправка сигнала"""
        if not hasattr(self.ui, 'selected_match') or not self.ui.selected_match:
            self.ui.update_analysis("❌ Сначала выберите матч")
            return
        
        match = self.ui.selected_match
        analysis = self.analyses.get(match.id)
        
        if not analysis:
            self.ui.update_analysis("❌ Анализ не найден")
            return
        
        if not analysis.has_signal or not analysis.next_signal:
            self.ui.update_analysis("❌ Нет активных сигналов на гол")
            return
        
        signal = analysis.next_signal
        message = analysis.format_telegram_message(match)
        
        if self.telegram.send_goal_signal(match, analysis, message):
            signal_key = f"{match.id}_{signal.predicted_minute}"
            self.state.add_sent_signal(signal_key)
            self.predictor.save_signal_to_history(match, signal)
            self.ui.update_analysis(f"✅ Сигнал отправлен в Telegram\n\n{message}")
        else:
            self.ui.update_analysis("❌ Ошибка отправки")
    
    def start_monitoring(self):
        """Запускает фоновый мониторинг"""
        
        def monitor():
            while not self.stop_monitoring:
                try:
                    time.sleep(self.update_interval)
                    
                    # Проверяем, не выполняется ли уже обновление
                    if not self.update_in_progress:
                        self.root.after(0, self.refresh_matches)
                    
                except Exception as e:
                    logger.error(f"Ошибка в мониторинге: {e}")
                    time.sleep(5)
        
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
    
    def run(self):
        """Запуск приложения"""
        try:
            self.root.mainloop()
        finally:
            self.stop_monitoring = True
            # Сохраняем все данные перед выходом
            self.predictor._save_all()


if __name__ == "__main__":
    app = FootballApp()
    app.run()